package movement;

import core.AbstractComponent;

public class RotationComponent extends AbstractComponent {

    public double rot;
    public double aVel;
}
