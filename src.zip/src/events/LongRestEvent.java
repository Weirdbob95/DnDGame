package events;

public class LongRestEvent extends Event {
}
