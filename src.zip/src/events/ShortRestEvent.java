package events;

public class ShortRestEvent extends Event {
}
