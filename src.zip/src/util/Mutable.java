package util;

public class Mutable<O> {

    public O o;

    public Mutable(O o) {
        this.o = o;
    }
}
