package maneuvers;

import creature.Creature;
import static enums.AbilityScore.WIS;
import events.SavingThrowEvent;
import events.TurnEndEvent;
import events.TurnStartEvent;
import events.attack.AttackDamageRollEvent;
import player.Player;

public class Menacing_Attack extends AttackManeuver {

    public Creature target;
    public boolean isNextTurn;

    public Menacing_Attack(Player player, ManeuversComponent mc) {
        super(player, mc);

        add(TurnStartEvent.class, e -> isNextTurn = (e.creature == player ? true : isNextTurn));
        add(TurnEndEvent.class, e -> {
            if (e.creature == player && isNextTurn) {
                //Make e.creature not frightened
            }
        });
    }

    @Override
    public void use(AttackDamageRollEvent e) {
        mc.addDieTo(e.a.damage);
        if (SavingThrowEvent.fail(e.a.target, WIS, mc.DC.get())) {
            //Make adre.a.creature frightened
        }
    }
}
