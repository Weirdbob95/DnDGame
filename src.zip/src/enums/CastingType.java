package enums;

public enum CastingType {

    NONE, FULL, HALF, THIRD;
}
